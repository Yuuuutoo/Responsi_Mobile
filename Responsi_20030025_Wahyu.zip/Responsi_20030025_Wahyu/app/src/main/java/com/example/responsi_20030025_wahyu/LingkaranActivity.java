package com.example.responsi_20030025_wahyu;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class LingkaranActivity extends AppCompatActivity {
    private EditText etJariJari;
    private TextView tvLuas, tvKeliling;
    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lingkaran);

        etJariJari = (EditText) findViewById(R.id.et_jari_jari);
        tvLuas = (TextView) findViewById(R.id.tvLuas);
        tvKeliling = (TextView) findViewById(R.id.tvKeliling);
        back = (Button) findViewById(R.id.btn_back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LingkaranActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

        findViewById(R.id.btn_hitung).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double jariJari = Double.parseDouble(etJariJari.getText().toString().trim());
                double luas = Math.PI * jariJari * jariJari;
                double keliling = 2 * Math.PI * jariJari;
                DecimalFormat decimalFormat = new DecimalFormat("#.##");

                tvLuas.setText(String.valueOf(decimalFormat.format(luas)));
                tvKeliling.setText(String.valueOf(decimalFormat.format(keliling)));
            }
        });
    }
}