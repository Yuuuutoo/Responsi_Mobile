package com.example.responsi_20030025_wahyu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class BolaActivity extends AppCompatActivity {
    EditText etJari;
    Button btnHitung;
    Button back2;
    TextView tvVolume;
    TextView tvKeliling;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bola);

        etJari = (EditText) findViewById(R.id.et_jari_jari);
        tvVolume = (TextView) findViewById(R.id.tvVolume);
        tvKeliling = (TextView) findViewById(R.id.tvKeliling);
        back2 = (Button) findViewById(R.id.btn_back2);

        back2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(BolaActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

        findViewById(R.id.btn_hitung).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int jari = Integer.parseInt(etJari.getText().toString());
                double volume = (4.0 / 3.0) * Math.PI * jari * jari * jari;
                double keliling = 4 * Math.PI * jari * jari;
                DecimalFormat decimalFormat = new DecimalFormat("#.##");

                tvVolume.setText(String.valueOf(decimalFormat.format(volume)));
                tvKeliling.setText(String.valueOf(decimalFormat.format(keliling)));

            }
        });
    }
}